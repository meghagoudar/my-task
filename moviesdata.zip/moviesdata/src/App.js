import './App.css';
import React, { Component } from 'react';
import Movies from './component/movies';


class App extends Component {
  state = {  

  }
  render() { 
    return ( 
      <main className="container">
        <Movies></Movies>
       
      </main>
     );
  }
}
 
export default App;

