import React,{Component} from 'react';
import { getMovies }  from '../services/fakeMovieService';
class Movies extends Component {
    state = { 
        movies:getMovies()
     };
     handledelete= movielist =>{
            //  console.log(movielist);
            const movienewlist = this.state.movies.filter(m => m._id !== movielist._id);
            // console.log(movienewlist)
            this.setState({movies:movienewlist});
            // console.log(this.state.movienewlist)

     };
    render() { 
        return ( 
            // <h2>Movie component </h2>
            <table className="table">
                <thead >
                    <tr>
                    <th>Title</th>
                    <th>Genre</th>
                    <th>Stock</th>
                    <th>Rate</th>
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                    {this.state.movies.map(movielist =>(   
                    <tr key={movielist._id}>
                    
                   <td>{movielist.title}</td>
                   <td>{movielist.genre.name}</td>
                   <td>{movielist.numberInStock}</td>
                   <td>{movielist.dailyRentalRate}</td>
                   <td><button onClick={()=>this.handledelete(movielist)}    
                     className="btn btn-danger btn-sm">Delete</button></td>
                         </tr>))}

                    
                </tbody>
            </table>
         );
    }
}
 
export default Movies;
