import React from 'react'

export default () => (
  <h1>
    Web Development Page
  </h1>
)