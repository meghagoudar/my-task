import React from 'react'

export default () => (
  <h1>
    Ui Development Page
  </h1>
)