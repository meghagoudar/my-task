import React from 'react'

export default () => (
    <h1>
        Angular Development Page
    </h1>
)