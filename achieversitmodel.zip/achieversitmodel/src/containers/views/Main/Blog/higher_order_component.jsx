import React, {Component} from 'react';

export default function Hoc(param1,Blog){
    return class extends Component{
        render(){
            return(
                <>
                    <Blog heading={param1}/>
                </>
            )
        }
    }
}