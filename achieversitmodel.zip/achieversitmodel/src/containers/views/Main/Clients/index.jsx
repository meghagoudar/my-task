import React from 'react'
//functional component
export default () => {
  return (
    <div>
      <h1>Clients Page</h1>
    </div>
  )
}