import React, { Component } from 'react'

// export default () => (
//   <h1>
//     Admin Dashboard
//   </h1>
// )

// class Visitor extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       noofvisitors: 0
//     }
//   }

//   increaseCount = () => {
//     this.setState({
//       noofvisitors: this.state.noofvisitors + 1
//     })
//   }

//   render() {
//     return (
//       <div>
//         <h3>No of visitors so far in this page - {this.state.noofvisitors}</h3>
//         <button onClick={this.increaseCount}>Add Visitors</button>
//       </div>
//     )
//   }
// }

// export default Visitor;

function visitorCount() {
  //export default () => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [visitors, setCount] = React.useState(0);
  return (
    <div>
      <h3>No Of visiotors so far in this page - {visitors}</h3>
      <button onClick={() => setCount(visitors + 1)}>Add Visitor</button>
    </div>
  )
}
export default visitorCount;