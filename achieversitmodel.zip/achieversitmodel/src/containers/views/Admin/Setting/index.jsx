import React, { useState, useEffect } from 'react'

function ExampleForHooks() {
  const [data, setData] = useState([]);
  const callInterval = () => {
    setInterval(function () {
      console.log('I am calling as per the interval')
    }, 500);
  }
  useEffect(() => {
    
    console.log('Hi welcome to useEffect');
    const apiUrl = 'https://api.github.com/users/hacktivist123/repos';
    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setData(data)
      });
    // if we want to implement componentWillUnmount
    // we should return a useEffect() from here, react will call this method before unmounting
    return () => console.log('this is phase where we can take care of compnent cleanup/side effects')
  }, [])

  return (
    <div>
      <h3>Example for useEffect Hook</h3>
      <button onClick={callInterval}>Click</button>
      <ul>
        {data.map(el => (
          <li key={el.id}>{el.name}</li>
        ))}
      </ul>
    </div>
  );
}
export default ExampleForHooks;