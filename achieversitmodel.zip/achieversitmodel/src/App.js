import React from "react";
import Routers from "./router";
function App() {
  return (
    <div className="App">
      <Routers />
    </div>
  );
}

export default App;
