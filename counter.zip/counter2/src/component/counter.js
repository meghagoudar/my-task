import React, { Component } from 'react';
class Counter extends Component {
    state = { 
        count:0
     };
     handleIncrement=()=>{
         this.setState ({count:this.state.count+1})
     }
     handleDecrement=()=>{
         this.setState({count:this.state.count-1})
     }
     clearCount=()=>{
         this.setState({count : 0})
     }
     formatcount(){
         const {count} =this.state;
         return count === 0?'0':count;
     }
     getBadgename(){
          return this.state.count===0? "bg-warning":"bg-secondary";
     }
    render() { 
        return (
            <div>
                <li className={this.getBadgename()}>{this.formatcount()}</li>
      <button onClick={this.handleIncrement}>increment</button>
      <button onClick={this.handleDecrement}>decrement</button>
      <button onClick={this.clearCount}>clear count</button>
      </div>
          )
    }
}
 
export default Counter;